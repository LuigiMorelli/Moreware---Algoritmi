#include <stdio.h>
#include <stdlib.h>

void usage() {
	printf("mcd 1.0 by MoreWare\n");
	printf("===================\n");
	printf("\nIl programma calcola il Massimo Comun Divisore usando l'algoritmo di Euclide.\n");
	printf("Vengono richiesti i due valori interi da confrontare sulla riga di comanado.\n\n");
	exit(1);
}

long mcd(long a, long b) {
  if (b == 0)
    return a;  
  else
    return mcd(b, a % b); 
}

int main(int argc, char** argv) {
	if (argc != 3) {
		usage();
	}
	
	long a = atoll(argv[1]);
	long b = atoll(argv[2]);
	
	printf ("Massimo comun divisore tra %li e %li = %li\n", a, b, mcd(a, b));
	return 0;
}
