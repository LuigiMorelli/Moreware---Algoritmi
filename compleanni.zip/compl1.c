// Quante persone sono necessarie per avere una probabilità p
// che almeno due di loro compiano gli anni nello stesso giorno?

#include <stdio.h>
#include <stdlib.h>

double p,q1,q2;
int    i;

int main(int argc, char* argv[]) {
	if (argc != 2) {
		printf ("\n   Uso: %s probabilita\n", argv[0]);
		return 1;
	}

	p = atof(argv[1]);

	if ((p < 0.0) || (p > 100.00)) {
		printf ("P non compresa tra 0%% e 100%%\n");
		return 2;
	}

	q1 = ( 100.0 - p ) / 100.0;
	q2 = 1.0;
	i = 0;

	do
		q2 *= (double)( 366 - ++i ) / 365.0;
	while ( q2 > q1 );

	printf( "Probabilita' del %.11f%% raggiunta con %d persone.\n", p, i );
	
	return 0;
}
