// Qual è la probabilità che, tra n persone, 
// almeno due compiano gli anni nello stesso giorno?

#include <stdio.h>
#include <stdlib.h>

double p;
int    n, i;

int main(int argc, char* argv[]) {

  if (argc != 2) {
    printf ("\n   Uso: %s giorni.\n", argv[0]);
    return 1;
  }

  n = atoi (argv[1]);
  
  if ( (n < 0) || (n > 365)) {
    printf ("Occorre un valore tra 0 e 365!\n");
    return 2;
  }

	p = 1.0; 
	
	for ( i = 1; i <= n; i++ )
		p *= (double)( 366 - i ) / 365.0;

	printf( "Probabilita' con %d persone: %.11f%%\n", n, 100.0*(1.0 - p) );
}
