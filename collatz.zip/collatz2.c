/*
 * collatz2.c - Catene di Collatz (o a chicco di grandine)
 *
 * Sia n un numero intero positivo ed f(n)  una sua funzione, tale che:
 *      se n è pari, f(n) = n/2
 *      se n è dispari, f(n) = 3n+1
 *
 * Scrivere un programma che riceva in input da riga di comando
 * un numero intero di tipo unsigned long long int e lo sottoponga 
 * a tale funzione finché la funzione non restituisce 1 
 *
 * Stampare i valori di ciascuna iterazione.
 *
 * Per tradurre da stringa a long long si usa la macro atoll()
 *
 * Facoltativo: inserire anche il numero di iterazioni ottenute.
 *              controllare che il numero di parametri passati sia 1
 *
 */
#include <stdio.h>
#include <stdlib.h>

int main ( int argc, char* argv[] ) {
    unsigned long long int n = 0;
    int iter = 0;
    
    printf("\nCollatz 1.0 - (C) by Moreware '22\n\n");
    
    if (argc != 2) {
        printf("Immettere un solo parametro numerico\n");
        return 0;
    }
    
    n = atoll(argv[1]);
    
    while (n != 1) {
        if (n % 2 == 0) {
            n = n / 2;
        } else {
            n = n*3 + 1;
        }
        iter++;
        printf("iterazione : %8i, numero %8llu\n", iter, n);
    }
    
    return 0;
}
