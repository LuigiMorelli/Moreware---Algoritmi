/*
 * collatz.c - Catene di Collatz (o a chicco di grandine)
 *
 * Sia n un numero intero positivo ed f(n)  una sua funzione, tale che:
 *      se n è pari, f(n) = n/2
 *      se n è dispari, f(n) = 3n+1
 *
 * Scrivere un programma che richieda in input un numero intero 
 * unsigned long long int e lo sottoponga a tale funzione 
 * finché la funzione non restituisce 1 
 *
 * Stampare i valori di ciascuna iternazione.
 *
 * Facoltativo: inserire anche il numero di iterazioni ottenute.
 *
 */
#include <stdio.h>

int main ( void ) {
    unsigned long long int n = 0;
    int iter = 0;
    
    printf ( "Inserisci il numero da testare : ");
    do {
        scanf("%llu", &n);
    } while (n <= 1 );
    
    printf("n = %llu\n", n);
    
    while (n != 1) {
        if (n % 2 == 0) {
            n = n / 2;
        } else {
            n = n*3 + 1;
        }
        iter++;
        printf("iterazione : %3i, numero %llu\n", iter, n);
    }
    
    return 0;
}
 
