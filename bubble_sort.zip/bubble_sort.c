// Algoritmi di ordinamento (bubble sort)
// 
// Serie Algoritmi #3

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 80000L			// Numero degli elementi da riordinare

time_t t1;
float dt;
long temp;

long elenco[N] = {0};	// Contenitore degli elementi, N posizioni

void creazione_valori() {
	
	// Carichiamo l'elenco con N elementi casuali tra 0 e 999.999.998
	for (int i = 0; i < N; i++) {
		elenco[i] = rand() % 999999999;
	}
}

void bubble_sort() {
	for (int i = 0; i < N - 1; i++) {
		for (int j = i + 1; j < N; j++) {
			// se gli elementi non sono in ordine crescente... 
			if (elenco[i] > elenco[j]) {
				// ...scambia le loro posizioni all'interno del vettore
				temp = elenco[i];
				elenco[i] = elenco[j];
				elenco[j] = temp;
			}
		}
	}
}

int main ( void ) {

	// Definiamo un cronometro per i tempi di esecuzione
	t1 = 0, dt = 0.0;
	srand(time(NULL));
	
	creazione_valori();
	
	bubble_sort();
	
	return 0;
}

