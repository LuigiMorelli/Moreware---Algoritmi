/*
 * Numeri di Armstrong (somme di potenze uguali)
 *
 * I Numeri di Armstrong sono numeri in cui la somma del cubo
 * di ciascuna cifra corrisponde al numero stesso.
 *
 * Esempio : 1^3 + 5^3 + 3^3 = 153
 *
 * Scrivere un programma che calcoli tutti i numeri di Armstrong 
 * compresi tra 1 e 2000.
 *
 */
#include <stdio.h>

int main ( void ) {
    int m, c, d, u;     // indici per il loop
    int temp = 0;       // variabile di appoggio temporanea
    int temp2;
    
    for (m = 0; m < 2; m++) {
        for (c = 0; c < 10; c++) {
            for (d = 0; d < 10; d ++) {
                for (u = 0; u < 10; u++) {
                    temp  = m * 1000 + c * 100 + d * 10 + u;  
                    temp2 = m*m*m + c*c*c + d*d*d + u*u*u;
                    //printf ("temp = %i, temp2 = %i\n", temp, temp2);
                    if (temp2 == temp) {
                        printf("Trovato %i\n", temp2);
                    }
                }
            }
        }
    }
    
    return 0;
}
