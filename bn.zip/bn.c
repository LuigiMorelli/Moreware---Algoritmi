// Battaglia navale
// 1 - creare una matrice con il campo di battaglia
// 2 - inserire 2 o 3 navi da 1 casella in posizione
// 3 - loop di richiesta coordinate finché ci sono navi
//
// Possibili aggiornamenti: 
//		a) una routine di controllo che limiti il range delle coordinate immesse ai soli valori possibili
//		b) una nuova routine per creare navi da più caselle
//		c) un algoritmo che consenta al computer di giocare contro un umano o contro se stesso
//		d) gestire un tavolo da gioco pseudografico usando i codici ANSI per la posizione

#include <stdio.h>
#include <stdlib.h>
#include  <time.h>

#define SIZE 10

int i, j;
time_t t;
int navi = 0;
int x,y; // coordinate
int matrice [SIZE][SIZE];
int n_tentativi = 0;
    
void inizializza_matrice( void );
void inserisci_navi( void );
void stampa_matrice( void ); 

int main()
{
    // Inizializziamo la matrice con tutti "0"
	inizializza_matrice();

    // inserire 3 valori random
    srand ((unsigned)time(&t));
	inserisci_navi();


    // Loop di richiesta coordinate
    while (navi != 0) {
		// stampa matrice funzione di DEBUG per controllare che tutto sia in ordine
		// stampa_matrice(); 
		   
        // richiediamo
        printf("Coordinata x = ");
        scanf("%i", &x);
        printf("Coordinata y = ");
        scanf("%i", &y);

        // controllare se il tiro ha avuto successo
        if (matrice[x][y] == 1) {
            printf("Colpito!\n");
            matrice[x][y] = 0;
            navi--;
        }
        else {
            printf("Colpo a vuoto!\n");
        }	// Manca il controllo del colpo ripetuto sulla stessa casella

        n_tentativi++;
    }

    printf("Il gioco è terminato in %i tentativi.\n", n_tentativi);

    return 0;
}

void inizializza_matrice() {
    for(i=0; i<SIZE; i++){
        for(j=0; j<SIZE; j++){
            matrice [j][i]= 0;
        }
    }
}

void inserisci_navi( void ) {
    for (int i = 0; i < 3; i++) {
        int a = random() % SIZE;
        int b = random() % SIZE;

        if (matrice[a][b] == 0) {
            matrice[a][b] = 1;
            navi++;
        }
    }
}

void stampa_matrice( void ) {
	// Stampare un header con i nomi delle colonne 
	printf("      ");
    for (int a = 0; a < SIZE; a++)
    {
		printf("%2i", a);
	}	
	printf("\n    ______________________\n");
	
	// Stampare il contenuto della matrice
    for (int a = 0; a < SIZE; a++)
    {
        // Stampare il nome della riga (0, 1, 2, 3...) prima delle relative caselle
        printf(" %2d | ", a);
        for(int b = 0; b < SIZE; b++) {
            printf("%2i", matrice[a][b]);
        }

        printf("\n");
    }
}
