/*
 * pw_cracking.c
 *
 * Il progetto crea una password numerica random di 6 elementi
 * Quindi imposta una routine per decifrarla.
 *
 * Si passa quindi ad una pw di 9 elementi numerici
 *
 * si modifica la routine per sostituire l'utente al motore random
 *
 * infine si analizza la routine per il controllo alfanumerico
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define MAX 1000000000    // 1G = 1"

unsigned long long int pw, i;
char risultato[80];

void impostaPassword() {
    // Creazione automatizzata pw random
    // srand(time(NULL));
    // pw = rand() % MAX;
    
    // Richiesta password
    printf("Inserisci la password che devo indovinare!\n");
    do {
        scanf("%llu", &pw);
    } while (pw == 0);
}


void decifraPassword1() {
    for (i = 0; i < MAX; i++) {
        if (i == pw) {
            printf("trovata! La password vale %llu\n", pw);
            return;
        }
    }
    printf("La password non è stata trovata!\n");
}

void decifraPassword2() {
    // trasformiamo pw in una stringa
    char str[80];
    int contatore = 0;

    sprintf(str, "%llu", pw);
    printf("pw in stringa = %s\n Lunghezza di str = %lu\n", str, strlen(str));
    int len = strlen(str);

    for (int i = 0; i < len; i++) {
        for (int j = 48; j < 58; j++) { // 32 < j < 128
            if (str[i] == j) {
                risultato[i] = j;
                break;
            }
        }
        contatore++;
    }
    risultato[len] = 0;
    printf("La stringa risultato è uguale a %s\nEffettuati %i loop\n", risultato, contatore);
    for (int k = 0; k < len; k++) {
        printf("%c ", risultato[k]);
    }
    printf("\n");
}

int main()
{
    impostaPassword();
    decifraPassword1();
    decifraPassword2();

    return 0;
}
