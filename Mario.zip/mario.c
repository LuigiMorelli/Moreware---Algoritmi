/*
 * mario.c
 * 
 * Costruisce una piramide a scalini con altezza compresa tra 1 e 8
 * versione con while()
 *
 */
#include <stdio.h>

int main() {
	int altezza = -1000;
	int h = 1;

	printf("Inserire l'altezza (1 - 8) ");
	do {
		scanf("%i", &altezza);
	} while ((altezza < 1) || (altezza > 8));

	// Disegna ciascuno dei livelli
	while (h <= (altezza)) {
		// Stampa gli spazi della riga
		for (int i = 0; i < (altezza - h); i++) {
			printf(" ");
		}
		// Stampa i cancelletti
		for (int i = (altezza - h); i < (altezza); i++) {
			printf("#");
		}	
		h++;
		// Vai a capo
		printf("\n");  	
	}	

	return 0;
}
