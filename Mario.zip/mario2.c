/*
 * mario2.c
 * 
 * Costruisce una piramide a scalini con altezza compresa tra 2 e 18
 * In salita e in discesa e con un fossato.
 * Allineare l'altezza (livelli) con il numero di mattoncini (che al momento è inferiore di 1) TO-DO
 * versione con for()
 *
 */
#include <stdio.h>

int main() {
	int altezza = -1000;
	int j,k;

	printf("Inserire l'altezza (2 - 18) ");
	do {
		scanf("%i", &altezza);
	} while ((altezza < 2) || (altezza > 18));

	// Disegna ciascuno dei livelli
	for (int i = 2; i <= altezza; i++) {
		// Stampa gli spazi della riga
		for ( j = altezza; j > i; j--) {
			printf(" ");
		}
		// Stampa i cancelletti
		for (k = 1; k <= i ; k++) {
			printf ("#");
		}
		// Stampa il fossato
		printf(" ");
		// Stampa i cancelletti
		for (k = 1; k <= i ; k++) {
			printf ("#");
		}		
		// Vai a capo
		printf("\n");
	}

	return 0;
}
