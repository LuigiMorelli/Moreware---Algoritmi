#include <stdio.h>
#include <stdlib.h>

/*
 * greedy.c
 *
 * Calcola il numero minimo di monete da restituire come resto
 * utilizzando i valori di conio 1c, 5c, 10c, 25c
 *
 */

// Definizione variabili
int resto;			// Resto da cambiare (in centesimi)
// int monete = 0;		// Numero monete da restituire

int monete[4] = {0, 0, 0, 0};

int main ( void ) {

	// Richiesta valore resto
	printf("A quanto corrisponde il resto ? ");
	do {
		scanf("%i", &resto);
	} while (resto <= 0);

	// Ciclo di controllo principale (eseguito finche' resto != 0)
	while (resto > 0) {
		// Conto le monete da 25c
		if(resto >= 25) {
			resto = resto - 25;
			monete[0]++;
		}
		else if (resto >= 10) {
			// Conto le monete da 10c
			resto = resto - 10;
			monete[1]++;
		}
		else if (resto >= 5) {
			resto = resto - 5;
			monete[2]++;
		}
		else {
			resto--;
			monete[3]++;
		}
	}

	printf("Sono necessarie %i monete.\n", monete[0] + monete[1] + monete[2] + monete[3]);
	printf("%3d monete da 25c\n%3d monete da 10c\n%3d monete da  5c\n%3d monete da  1c\n", monete[0], monete[1], monete[2], monete[3]);

	return 0;
}
