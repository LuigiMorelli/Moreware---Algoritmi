// Algoritmi di Ricerca (lineare e binaria)
// 
// Serie Algoritmi #2

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 100000000L

int elenco[N] = {0};  			// La nostra lista di elementi
time_t t1, dt; 					// I timer per il cronometraggio
int item = 1000000000;			// L'elemento che dobbiamo trovare nell'elenco
int temp;

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int Binary_Search(int array[], int elemento)  {
    int start = 0, end = N - 1, centro = 0;
    while (start <= end) {
        centro = (start + end) / 2;
        if (elemento < array[centro]) {
            end = centro - 1;
        } else {
            if (elemento > array[centro])
                start = centro + 1;
            else
                return centro; // Caso: elemento==array[centro]
        }
    }
    return -1;
}


int main() {

	// Definiamo un cronometro per i tempi di esecuzione
	t1 = 0, dt = 0.0;
	srand(time(NULL));
	
	// Carichiamo l'elenco con N elementi casuali tra 0 e 999.999.998
	for (int i = 0; i < N; i++) {
		elenco[i] = rand() % 999999999;
	}
	// Aggiungiamo il nostro item alla fine dell'elenco
	elenco[N - 1] = item;
	
	// Eseguiamo l'ordinamento degli elementi
	qsort(elenco, N, sizeof(int), cmpfunc);
	
	// Ricerca lineare
	t1 = clock();
	for (int i = 0; i < N; i++)  {
		if (elenco[i] == item) {
		  	dt = clock();
  		
			printf("Trovato in %6.4f sec. con ricerca lineare.\n", (float)(dt-t1)*100/CLOCKS_PER_SEC);
			break;
		}
	}
	
	// Ricerca binaria
	t1 = clock();
	Binary_Search(elenco, item);
	dt = clock();
	printf("Trovato in %6.4f sec. con ricerca binaria.\n", (float)(dt-t1)*100/CLOCKS_PER_SEC);
	
	return 0;
}
